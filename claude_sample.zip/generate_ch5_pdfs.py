# -*- coding: utf-8 -*-
"""
Chapter 5 실습용 PDF 파일 생성 스크립트
fpdf2 라이브러리를 사용하여 6개의 PDF 파일을 생성합니다.
"""

import os
from fpdf import FPDF

# ─── 경로 설정 ───
SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
OUTPUT_DIR = os.path.join(SCRIPT_DIR, "kr", "chapter5")
FONT_PATH = "C:/Windows/Fonts/malgun.ttf"
FONT_BOLD_PATH = "C:/Windows/Fonts/malgunbd.ttf"

os.makedirs(OUTPUT_DIR, exist_ok=True)


# ─── 공통 베이스 클래스 ───
class KoreanPDF(FPDF):
    """한글 폰트가 설정된 기본 PDF 클래스"""

    def __init__(self, orientation="portrait", unit="mm", format="A4"):
        super().__init__(orientation=orientation, unit=unit, format=format)
        self.add_font("malgun", "", FONT_PATH)
        self.add_font("malgun", "B", FONT_BOLD_PATH)
        self.set_auto_page_break(auto=True, margin=25)

    def footer(self):
        self.set_y(-15)
        self.set_font("malgun", "", 8)
        self.set_text_color(128, 128, 128)
        self.cell(0, 10, f"- {self.page_no()} -", align="C")


# ═══════════════════════════════════════════════════════════════
# 1. 경쟁사_분석_보고서_샘플.pdf
# ═══════════════════════════════════════════════════════════════
def create_competitor_report():
    pdf = KoreanPDF()

    # ── 표지 ──
    pdf.add_page()
    pdf.set_fill_color(0, 51, 102)
    pdf.rect(0, 0, 210, 297, "F")

    # 상단 장식선
    pdf.set_fill_color(0, 102, 178)
    pdf.rect(0, 80, 210, 3, "F")

    pdf.set_y(95)
    pdf.set_font("malgun", "B", 28)
    pdf.set_text_color(255, 255, 255)
    pdf.cell(0, 15, "2026년 상반기", align="C", new_x="LMARGIN", new_y="NEXT")
    pdf.cell(0, 15, "경쟁사 동향 분석 보고서", align="C", new_x="LMARGIN", new_y="NEXT")

    pdf.ln(10)
    pdf.set_fill_color(0, 102, 178)
    pdf.rect(70, pdf.get_y(), 70, 1, "F")

    pdf.ln(15)
    pdf.set_font("malgun", "", 14)
    pdf.cell(0, 10, "국내 SaaS 시장 및 주요 경쟁사 전략 분석", align="C", new_x="LMARGIN", new_y="NEXT")

    pdf.ln(40)
    pdf.set_font("malgun", "", 12)
    pdf.cell(0, 8, "작성: 전략기획팀", align="C", new_x="LMARGIN", new_y="NEXT")
    pdf.cell(0, 8, "2026년 6월", align="C", new_x="LMARGIN", new_y="NEXT")

    pdf.ln(5)
    pdf.set_font("malgun", "", 10)
    pdf.cell(0, 8, "Confidential", align="C", new_x="LMARGIN", new_y="NEXT")

    # 하단 장식선
    pdf.set_fill_color(0, 102, 178)
    pdf.rect(0, 260, 210, 3, "F")

    # ── 목차 ──
    pdf.add_page()
    pdf.set_text_color(0, 0, 0)
    pdf.set_font("malgun", "B", 20)
    pdf.cell(0, 15, "목 차", align="C", new_x="LMARGIN", new_y="NEXT")
    pdf.ln(10)

    toc_items = [
        ("Executive Summary", 3),
        ("1. 시장 개요", 4),
        ("   1.1 시장 규모 및 성장률", 4),
        ("   1.2 산업별 도입률", 4),
        ("2. 주요 트렌드", 5),
        ("   2.1 생성형 AI 주류화", 5),
        ("   2.2 AI 에이전트 부상", 5),
        ("   2.3 데이터 거버넌스", 6),
        ("   2.4 AI 인력 부족", 6),
        ("   2.5 비용 최적화", 6),
        ("3. 경쟁사 분석", 7),
        ("   3.1 A사 (넥스트웨어)", 7),
        ("   3.2 B사 (테크노솔루션)", 7),
        ("   3.3 C사 (디지털윈드)", 8),
        ("4. 당사 시사점 및 권장사항", 9),
    ]
    pdf.set_font("malgun", "", 12)
    for title, page_num in toc_items:
        w = pdf.get_string_width(title)
        pdf.cell(120, 8, title)
        pdf.cell(0, 8, str(page_num), align="R", new_x="LMARGIN", new_y="NEXT")

    # ── Executive Summary ──
    pdf.add_page()
    pdf.set_font("malgun", "B", 18)
    pdf.set_text_color(0, 51, 102)
    pdf.cell(0, 12, "Executive Summary", new_x="LMARGIN", new_y="NEXT")
    pdf.set_draw_color(0, 51, 102)
    pdf.line(10, pdf.get_y(), 200, pdf.get_y())
    pdf.ln(8)

    pdf.set_font("malgun", "", 11)
    pdf.set_text_color(0, 0, 0)
    summary_text = (
        "2026년 국내 SaaS 시장은 전년 대비 28% 성장하여 4조 2천억 원 규모에 달하였습니다. "
        "이는 아시아태평양 지역의 디지털 전환 가속화와 생성형 AI 기술의 급속한 보급에 기인합니다.\n\n"
        "본 보고서는 주요 경쟁사 3개사(넥스트웨어, 테크노솔루션, 디지털윈드)의 전략 변화를 "
        "심층 분석하고, 당사에 미치는 영향 및 대응 전략을 도출하였습니다.\n\n"
        "주요 발견사항:\n"
        "  - 넥스트웨어(A사)가 시장점유율 12%에서 23%로 급성장하며 최대 변수로 부상\n"
        "  - 테크노솔루션(B사)은 35%로 1위를 유지하나 성장 모멘텀이 둔화\n"
        "  - 디지털윈드(C사)는 공격적 가격 전략으로 클라우드 네이티브 고객층 확보\n"
        "  - 생성형 AI와 AI 에이전트가 시장 판도를 변화시키는 핵심 기술로 확인\n"
        "  - 기업의 85%가 AI 거버넌스를 최우선 과제로 인식\n\n"
        "당사는 고영향-저위험 사용 사례 중심의 단계적 AI 도입과 함께, "
        "AI 인재 확보 및 거버넌스 체계 조기 수립이 시급한 것으로 판단됩니다."
    )
    pdf.multi_cell(0, 7, summary_text)

    # ── 1. 시장 개요 ──
    pdf.add_page()
    pdf.set_font("malgun", "B", 18)
    pdf.set_text_color(0, 51, 102)
    pdf.cell(0, 12, "1. 시장 개요", new_x="LMARGIN", new_y="NEXT")
    pdf.set_draw_color(0, 51, 102)
    pdf.line(10, pdf.get_y(), 200, pdf.get_y())
    pdf.ln(8)

    pdf.set_font("malgun", "B", 13)
    pdf.set_text_color(0, 51, 102)
    pdf.cell(0, 10, "1.1 시장 규모 및 성장률", new_x="LMARGIN", new_y="NEXT")
    pdf.ln(3)

    pdf.set_font("malgun", "", 11)
    pdf.set_text_color(0, 0, 0)
    market_text = (
        "국내 기업용 SaaS 시장은 2026년 4조 2,000억 원 규모로, 전년 대비 28% 성장하였습니다. "
        "2027년에는 5조 3,000억 원에 이를 것으로 전망되며, 2024~2027년 연평균 성장률(CAGR)은 "
        "26.5%로 글로벌 평균을 상회합니다.\n\n"
        "지역별 성장률 비교:\n"
        "  - 아시아태평양: 41% (글로벌 최고 성장률)\n"
        "  - 북미: 28%\n"
        "  - 유럽: 25%\n\n"
        "한국 기업용 AI 시장은 1조 1,340억 원으로 글로벌 5위 수준이며, "
        "정부의 AI 국가전략과 민간 투자 확대에 힘입어 빠르게 성장하고 있습니다."
    )
    pdf.multi_cell(0, 7, market_text)

    pdf.ln(8)
    pdf.set_font("malgun", "B", 13)
    pdf.set_text_color(0, 51, 102)
    pdf.cell(0, 10, "1.2 산업별 AI/SaaS 도입률", new_x="LMARGIN", new_y="NEXT")
    pdf.ln(3)

    # 표
    pdf.set_font("malgun", "B", 10)
    pdf.set_fill_color(0, 51, 102)
    pdf.set_text_color(255, 255, 255)
    pdf.cell(40, 9, "산업", border=1, fill=True, align="C")
    pdf.cell(30, 9, "도입률", border=1, fill=True, align="C")
    pdf.cell(0, 9, "주요 활용 사례", border=1, fill=True, align="C", new_x="LMARGIN", new_y="NEXT")

    pdf.set_font("malgun", "", 10)
    pdf.set_text_color(0, 0, 0)
    table_data = [
        ("금융", "78%", "사기 탐지, 리스크 모델링, 신용 평가"),
        ("의료", "62%", "진단 영상 분석, 신약 개발, 환자 관리"),
        ("제조", "58%", "예측 정비, 품질 관리, 공급망 최적화"),
        ("유통", "55%", "개인화 추천, 수요 예측, 재고 관리"),
        ("전문서비스", "47%", "문서 분석, 지식 관리, 계약 검토"),
    ]
    for i, (sector, rate, use_case) in enumerate(table_data):
        fill = i % 2 == 0
        if fill:
            pdf.set_fill_color(230, 240, 250)
        pdf.cell(40, 8, sector, border=1, fill=fill, align="C")
        pdf.cell(30, 8, rate, border=1, fill=fill, align="C")
        pdf.cell(0, 8, use_case, border=1, fill=fill, new_x="LMARGIN", new_y="NEXT")

    pdf.ln(5)
    pdf.set_font("malgun", "", 9)
    pdf.set_text_color(100, 100, 100)
    pdf.cell(0, 6, "출처: 전략기획팀 연례 기업 AI 서베이 (18개국 2,400개 조직)", new_x="LMARGIN", new_y="NEXT")

    # ── 2. 주요 트렌드 ──
    pdf.add_page()
    pdf.set_font("malgun", "B", 18)
    pdf.set_text_color(0, 51, 102)
    pdf.cell(0, 12, "2. 주요 트렌드", new_x="LMARGIN", new_y="NEXT")
    pdf.set_draw_color(0, 51, 102)
    pdf.line(10, pdf.get_y(), 200, pdf.get_y())
    pdf.ln(8)

    trends = [
        ("2.1 생성형 AI 주류화",
         "지식근로자의 67%가 주 1회 이상 AI 어시스턴트를 업무에 활용하고 있으며, "
         "이는 전년 대비 23%p 증가한 수치입니다. 생성형 AI는 더 이상 실험적 기술이 아닌 "
         "일상적 업무 도구로 자리잡았습니다. 특히 문서 작성, 코드 리뷰, 데이터 분석 분야에서 "
         "활용도가 높으며, 기업의 72%가 2026년 내 생성형 AI 예산을 확대할 계획입니다."),
        ("2.2 AI 에이전트 부상",
         "단순 질의응답을 넘어 멀티스텝 워크플로우를 자동으로 수행하는 AI 에이전트가 "
         "차세대 생산성 도구로 주목받고 있습니다. 선도 기업의 34%가 이미 AI 에이전트를 "
         "파일럿 운영 중이며, 고객 서비스, 영업 지원, IT 운영 영역에서 가시적 성과를 "
         "보이고 있습니다."),
        ("2.3 데이터 거버넌스 중요성 증대",
         "포춘 500 기업의 85%가 Chief AI Officer(CAIO)를 신설하는 등, AI 거버넌스가 "
         "경영진 어젠다의 최상위에 자리잡았습니다. AI 활용 확대에 따른 데이터 품질, "
         "프라이버시, 편향성 관리가 핵심 과제로 부상하였습니다."),
        ("2.4 AI 인력 부족",
         "글로벌 기업의 61%가 AI 스킬 갭(skill gap)을 AI 도입의 1순위 장벽으로 "
         "꼽고 있습니다. 특히 AI 엔지니어, 데이터 사이언티스트, MLOps 전문가에 대한 "
         "수요가 공급을 크게 초과하고 있으며, 평균 채용 기간이 6.2개월에 달합니다."),
        ("2.5 비용 최적화",
         "AI 도구에 대한 월 사용자당 평균 지출은 47달러로, 전년 대비 15% 증가하였습니다. "
         "기업들은 AI 투자 대비 효과(ROI)를 엄격하게 관리하기 시작했으며, "
         "FinOps와 유사한 'AIOps 비용 관리' 개념이 확산되고 있습니다."),
    ]
    for title, content in trends:
        pdf.set_font("malgun", "B", 13)
        pdf.set_text_color(0, 51, 102)
        pdf.cell(0, 10, title, new_x="LMARGIN", new_y="NEXT")
        pdf.set_font("malgun", "", 11)
        pdf.set_text_color(0, 0, 0)
        pdf.multi_cell(0, 7, content)
        pdf.ln(5)

    # ── 3. 경쟁사 분석 ──
    pdf.add_page()
    pdf.set_font("malgun", "B", 18)
    pdf.set_text_color(0, 51, 102)
    pdf.cell(0, 12, "3. 경쟁사 분석", new_x="LMARGIN", new_y="NEXT")
    pdf.set_draw_color(0, 51, 102)
    pdf.line(10, pdf.get_y(), 200, pdf.get_y())
    pdf.ln(8)

    competitors = [
        ("3.1 A사 - 넥스트웨어",
         "시장점유율: 12% → 23% (전년 대비 11%p 상승)\n\n"
         "넥스트웨어는 2026년 상반기 가장 주목할 만한 성장세를 보이고 있습니다. "
         "규제산업(금융, 의료, 공공)에 특화된 컴플라이언스 AI 솔루션을 앞세워 "
         "대형 고객사를 빠르게 확보하고 있습니다.\n\n"
         "주요 전략:\n"
         "  - 규제 준수 자동화 플랫폼 'NexComply' 출시\n"
         "  - 금융감독원, 식약처 등 규제기관과의 파트너십 강화\n"
         "  - Series C 투자 유치 (1,500억 원)\n"
         "  - AI 연구소 확장 (연구인력 80명 → 150명)\n\n"
         "위협 수준: 높음 - 당사 금융권 고객 3곳이 넥스트웨어 솔루션을 병행 검토 중"),
        ("3.2 B사 - 테크노솔루션",
         "시장점유율: 35% (1위 유지, 전년 대비 1%p 하락)\n\n"
         "테크노솔루션은 여전히 시장 1위를 유지하고 있으나, 성장 모멘텀이 둔화되고 있습니다. "
         "레거시 제품 의존도가 높고 클라우드 전환 속도가 경쟁사 대비 느린 것이 약점입니다.\n\n"
         "주요 전략:\n"
         "  - 클라우드 전환 가속화 (2027년까지 매출 60% 클라우드 목표)\n"
         "  - AI 스타트업 2곳 인수 (총 800억 원)\n"
         "  - 기존 엔터프라이즈 고객 대상 업셀링 집중\n"
         "  - 글로벌 확장은 보류, 국내 시장 방어에 집중\n\n"
         "위협 수준: 중간 - 직접적 경쟁 영역이 넓으나, 혁신 속도 저하가 관찰됨"),
        ("3.3 C사 - 디지털윈드",
         "시장점유율: 18% (클라우드 네이티브 세그먼트 1위)\n\n"
         "디지털윈드는 클라우드 기반 기업, 스타트업, 스케일업 고객층에서 강세를 보이며 "
         "공격적 가격 정책으로 빠르게 고객을 확보하고 있습니다.\n\n"
         "주요 전략:\n"
         "  - 업계 최저가 정책 (경쟁사 대비 20~30% 저렴)\n"
         "  - 무료 티어 확대 및 프리미엄 전환 유도\n"
         "  - 오픈소스 커뮤니티 활용한 개발자 생태계 구축\n"
         "  - 동남아시아 시장 진출 (베트남, 인도네시아)\n\n"
         "위협 수준: 중간 - 가격 경쟁력이 강점이나, 엔터프라이즈 레퍼런스 부족"),
    ]
    for title, content in competitors:
        pdf.set_font("malgun", "B", 13)
        pdf.set_text_color(0, 51, 102)
        pdf.cell(0, 10, title, new_x="LMARGIN", new_y="NEXT")
        pdf.set_font("malgun", "", 11)
        pdf.set_text_color(0, 0, 0)
        pdf.multi_cell(0, 7, content)
        pdf.ln(5)
        if pdf.get_y() > 250:
            pdf.add_page()

    # ── 4. 시사점 및 권장사항 ──
    pdf.add_page()
    pdf.set_font("malgun", "B", 18)
    pdf.set_text_color(0, 51, 102)
    pdf.cell(0, 12, "4. 당사 시사점 및 권장사항", new_x="LMARGIN", new_y="NEXT")
    pdf.set_draw_color(0, 51, 102)
    pdf.line(10, pdf.get_y(), 200, pdf.get_y())
    pdf.ln(8)

    recommendations = [
        ("4.1 고영향-저위험 사용 사례부터 시작",
         "전사적 AI 전환보다는 ROI가 명확하고 리스크가 낮은 영역에서 "
         "먼저 성과를 입증하는 전략이 필요합니다. 문서 자동화, 고객 FAQ 챗봇, "
         "내부 지식 검색 등이 적합한 초기 사용 사례입니다."),
        ("4.2 AI 리터러시 교육 투자",
         "전 직원 대상 기초 AI 교육과 함께, 부서별 맞춤형 심화 교육을 "
         "병행하여 조직 전반의 AI 활용 역량을 높여야 합니다. "
         "연간 교육 예산의 15%를 AI 관련 교육에 배정할 것을 권장합니다."),
        ("4.3 조기 거버넌스 수립",
         "AI 활용이 확대되기 전에 데이터 거버넌스, AI 윤리 정책, "
         "모델 관리 체계를 선제적으로 수립해야 합니다. "
         "CAIO(Chief AI Officer) 또는 이에 준하는 역할의 신설을 검토할 필요가 있습니다."),
        ("4.4 성과 측정 체계 마련",
         "AI 투자에 대한 명확한 KPI와 측정 체계를 수립하여 "
         "경영진의 지속적 투자 의사결정을 지원해야 합니다. "
         "비용 절감, 생산성 향상, 고객 만족도 등 다차원적 평가 프레임워크가 필요합니다."),
        ("4.5 확장 계획 수립",
         "초기 파일럿의 성과를 기반으로 전사 확산 로드맵을 수립해야 합니다. "
         "기술 인프라, 인력 계획, 예산 배정 등을 포함한 3년 단위의 AI 전환 계획을 "
         "수립할 것을 권장합니다."),
    ]
    for title, content in recommendations:
        pdf.set_font("malgun", "B", 12)
        pdf.set_text_color(0, 51, 102)
        pdf.cell(0, 10, title, new_x="LMARGIN", new_y="NEXT")
        pdf.set_font("malgun", "", 11)
        pdf.set_text_color(0, 0, 0)
        pdf.multi_cell(0, 7, content)
        pdf.ln(4)

    pdf.ln(10)
    pdf.set_draw_color(0, 51, 102)
    pdf.line(10, pdf.get_y(), 200, pdf.get_y())
    pdf.ln(5)
    pdf.set_font("malgun", "", 9)
    pdf.set_text_color(100, 100, 100)
    pdf.multi_cell(0, 5,
        "출처: 전략기획팀 연례 기업 AI 서베이 (18개국 2,400개 조직)\n"
        "본 보고서는 사내 한정 배포용이며, 외부 유출을 금합니다."
    )

    output_path = os.path.join(OUTPUT_DIR, "경쟁사_분석_보고서_샘플.pdf")
    pdf.output(output_path)
    print(f"  [OK] {output_path}")


# ═══════════════════════════════════════════════════════════════
# 2~4. 벤더 제안서 3종
# ═══════════════════════════════════════════════════════════════
def create_vendor_proposal(vendor_info):
    """범용 벤더 제안서 생성 함수"""
    pdf = KoreanPDF()
    vi = vendor_info

    # ── 표지 ──
    pdf.add_page()
    pdf.set_fill_color(*vi["color_primary"])
    pdf.rect(0, 0, 210, 297, "F")

    # 장식 요소
    pdf.set_fill_color(*vi["color_accent"])
    pdf.rect(0, 70, 210, 4, "F")
    pdf.rect(0, 240, 210, 4, "F")

    pdf.set_y(90)
    pdf.set_font("malgun", "B", 16)
    pdf.set_text_color(255, 255, 255)
    pdf.cell(0, 10, vi["company_name"], align="C", new_x="LMARGIN", new_y="NEXT")

    pdf.ln(5)
    pdf.set_font("malgun", "B", 26)
    pdf.cell(0, 15, vi["product_name"], align="C", new_x="LMARGIN", new_y="NEXT")
    pdf.cell(0, 15, "도입 제안서", align="C", new_x="LMARGIN", new_y="NEXT")

    pdf.ln(15)
    pdf.set_font("malgun", "", 13)
    pdf.cell(0, 8, "사내 협업 소프트웨어 교체 프로젝트", align="C", new_x="LMARGIN", new_y="NEXT")

    pdf.ln(30)
    pdf.set_font("malgun", "", 11)
    pdf.cell(0, 8, f"제안사: {vi['company_name']}", align="C", new_x="LMARGIN", new_y="NEXT")
    pdf.cell(0, 8, "수신: 귀사 IT기획팀", align="C", new_x="LMARGIN", new_y="NEXT")
    pdf.cell(0, 8, "2026년 5월", align="C", new_x="LMARGIN", new_y="NEXT")

    def section_title(text):
        pdf.add_page()
        pdf.set_font("malgun", "B", 18)
        pdf.set_text_color(*vi["color_primary"])
        pdf.cell(0, 12, text, new_x="LMARGIN", new_y="NEXT")
        pdf.set_draw_color(*vi["color_primary"])
        pdf.line(10, pdf.get_y(), 200, pdf.get_y())
        pdf.ln(8)
        pdf.set_text_color(0, 0, 0)

    def sub_title(text):
        pdf.set_font("malgun", "B", 13)
        pdf.set_text_color(*vi["color_primary"])
        pdf.cell(0, 10, text, new_x="LMARGIN", new_y="NEXT")
        pdf.ln(2)
        pdf.set_text_color(0, 0, 0)

    def body_text(text):
        pdf.set_font("malgun", "", 11)
        pdf.set_x(pdf.l_margin)
        pdf.multi_cell(w=0, h=7, text=text, new_x="LMARGIN", new_y="NEXT")
        pdf.ln(3)

    def bullet_list(items):
        pdf.set_font("malgun", "", 11)
        for item in items:
            pdf.set_x(pdf.l_margin)
            pdf.multi_cell(w=0, h=7, text=f"  -  {item}", new_x="LMARGIN", new_y="NEXT")
        pdf.ln(3)

    # ── 1. 회사 소개 ──
    section_title("1. 회사 소개")
    body_text(vi["company_intro"])
    bullet_list(vi["company_highlights"])

    # ── 2. 솔루션 개요 ──
    section_title("2. 솔루션 개요")
    body_text(vi["solution_overview"])

    # ── 3. 기능 상세 ──
    section_title("3. 기능 상세")
    for feat_title, feat_desc in vi["features"]:
        sub_title(feat_title)
        body_text(feat_desc)

    # ── 4. 가격 체계 ──
    section_title("4. 가격 체계")
    sub_title("4.1 라이선스 비용")
    body_text(vi["pricing_text"])

    # 가격표
    pdf.set_font("malgun", "B", 10)
    pdf.set_fill_color(*vi["color_primary"])
    pdf.set_text_color(255, 255, 255)
    for col_name, col_w in vi["pricing_table_header"]:
        pdf.cell(col_w, 9, col_name, border=1, fill=True, align="C")
    pdf.ln()

    pdf.set_font("malgun", "", 10)
    pdf.set_text_color(0, 0, 0)
    for i, row in enumerate(vi["pricing_table_data"]):
        fill = i % 2 == 0
        if fill:
            pdf.set_fill_color(235, 245, 255)
        for j, (_, col_w) in enumerate(vi["pricing_table_header"]):
            pdf.cell(col_w, 8, row[j], border=1, fill=fill, align="C")
        pdf.ln()

    pdf.ln(5)
    sub_title("4.2 도입 비용")
    body_text(vi["implementation_cost_text"])

    sub_title("4.3 총 비용 요약 (1년 차)")
    body_text(vi["total_cost_text"])

    # ── 5. 도입 일정 ──
    section_title("5. 도입 일정")
    body_text(vi["timeline_text"])

    # 일정표
    pdf.set_font("malgun", "B", 10)
    pdf.set_fill_color(*vi["color_primary"])
    pdf.set_text_color(255, 255, 255)
    pdf.cell(30, 9, "단계", border=1, fill=True, align="C")
    pdf.cell(60, 9, "내용", border=1, fill=True, align="C")
    pdf.cell(30, 9, "기간", border=1, fill=True, align="C")
    pdf.cell(0, 9, "비고", border=1, fill=True, align="C")
    pdf.ln()

    pdf.set_font("malgun", "", 10)
    pdf.set_text_color(0, 0, 0)
    for i, row in enumerate(vi["timeline_data"]):
        fill = i % 2 == 0
        if fill:
            pdf.set_fill_color(235, 245, 255)
        pdf.cell(30, 8, row[0], border=1, fill=fill, align="C")
        pdf.cell(60, 8, row[1], border=1, fill=fill)
        pdf.cell(30, 8, row[2], border=1, fill=fill, align="C")
        pdf.cell(0, 8, row[3], border=1, fill=fill)
        pdf.ln()

    # ── 6. 기술 지원 체계 ──
    section_title("6. 기술 지원 체계")
    body_text(vi["support_text"])
    bullet_list(vi["support_details"])

    # ── 7. 레퍼런스 고객사 ──
    section_title("7. 레퍼런스 고객사")
    body_text(vi["reference_text"])

    # 레퍼런스 테이블
    pdf.set_font("malgun", "B", 10)
    pdf.set_fill_color(*vi["color_primary"])
    pdf.set_text_color(255, 255, 255)
    pdf.cell(40, 9, "고객사", border=1, fill=True, align="C")
    pdf.cell(25, 9, "산업", border=1, fill=True, align="C")
    pdf.cell(25, 9, "규모", border=1, fill=True, align="C")
    pdf.cell(0, 9, "도입 성과", border=1, fill=True, align="C")
    pdf.ln()

    pdf.set_font("malgun", "", 10)
    pdf.set_text_color(0, 0, 0)
    for i, row in enumerate(vi["reference_data"]):
        fill = i % 2 == 0
        if fill:
            pdf.set_fill_color(235, 245, 255)
        pdf.cell(40, 8, row[0], border=1, fill=fill, align="C")
        pdf.cell(25, 8, row[1], border=1, fill=fill, align="C")
        pdf.cell(25, 8, row[2], border=1, fill=fill, align="C")
        pdf.cell(0, 8, row[3], border=1, fill=fill)
        pdf.ln()

    pdf.ln(10)
    pdf.set_font("malgun", "", 10)
    pdf.set_text_color(100, 100, 100)
    pdf.multi_cell(0, 6,
        f"본 제안서에 관한 문의사항은 {vi['company_name']} 영업팀으로 연락 바랍니다.\n"
        f"담당: {vi['contact_person']} | {vi['contact_email']} | {vi['contact_phone']}"
    )

    output_path = os.path.join(OUTPUT_DIR, vi["filename"])
    pdf.output(output_path)
    print(f"  [OK] {output_path}")


def create_all_vendor_proposals():
    # ── 벤더A: 워크플로우 프로 ──
    vendor_a = {
        "filename": "벤더A_워크플로우프로_제안서.pdf",
        "company_name": "주식회사 워크플로우랩",
        "product_name": "워크플로우 프로",
        "color_primary": (0, 102, 51),
        "color_accent": (0, 153, 76),
        "company_intro": (
            "주식회사 워크플로우랩은 2018년 설립된 기업용 협업 소프트웨어 전문 기업입니다. "
            "직원 200명 규모로 국내 1,200개 이상의 고객사에 협업 솔루션을 제공하고 있으며, "
            "특히 중견기업 및 대기업을 대상으로 안정적인 서비스를 운영하고 있습니다."
        ),
        "company_highlights": [
            "설립: 2018년 (8년 차)",
            "직원 수: 200명 (R&D 인력 80명)",
            "고객사: 국내 1,200개사",
            "주요 인증: ISO 27001, ISMS-P",
            "연간 매출: 약 250억 원 (2025년 기준)",
        ],
        "solution_overview": (
            "워크플로우 프로는 메시징, 파일 공유, 화상회의, 프로젝트 관리를 하나의 플랫폼에서 "
            "제공하는 통합 협업 솔루션입니다. 직관적인 UI와 강력한 프로젝트 관리 기능을 갖추고 있어 "
            "업무 프로세스의 효율화와 팀 간 소통 강화에 최적화되어 있습니다.\n\n"
            "귀사의 협업 소프트웨어 교체 프로젝트에 맞춰, 직원 320명, 5개 부서 환경에 "
            "최적화된 구성을 제안드립니다."
        ),
        "features": [
            ("메시징 및 커뮤니케이션", "1:1 채팅, 그룹 채팅, 채널(공개/비공개), 스레드 기능을 지원합니다. "
             "메시지 검색, 북마크, 멘션, 이모지 반응 등 풍부한 커뮤니케이션 기능을 제공합니다."),
            ("파일 공유 및 문서 관리", "사용자당 100GB의 클라우드 스토리지를 제공하며, "
             "파일 버전 관리, 실시간 공동 편집, 문서 내 코멘트 기능을 지원합니다."),
            ("화상회의", "최대 50인 동시 참여 가능한 화상회의 기능을 제공합니다. "
             "화면 공유, 녹화, 배경 흐림, 실시간 자막(한/영) 기능을 지원합니다."),
            ("프로젝트 관리", "간트 차트, 칸반 보드, 타임라인 뷰를 통한 프로젝트 관리가 가능합니다. "
             "작업 배정, 진척률 추적, 마일스톤 관리, 리소스 관리 기능을 제공합니다."),
            ("모바일 지원", "iOS/Android 전용 앱을 제공하며, 데스크톱과 동일한 기능을 모바일에서 이용 가능합니다."),
            ("보안", "SSO(SAML 2.0, OAuth), 상세 감사 로그, AES-256 암호화, "
             "ISO 27001 인증을 통해 엔터프라이즈 수준의 보안을 보장합니다."),
            ("외부 서비스 연동", "Outlook, Google Workspace, SAP ERP, 네이버웍스 등 "
             "주요 업무 도구와의 연동을 지원합니다. REST API를 통한 커스텀 연동도 가능합니다."),
        ],
        "pricing_text": "워크플로우 프로는 사용자 수 기반의 투명한 과금 체계를 제공합니다.",
        "pricing_table_header": [
            ("항목", 50), ("월간 요금", 40), ("연간 계약 시", 40), ("비고", 60),
        ],
        "pricing_table_data": [
            ("기본 라이선스", "15,000원/인", "12,000원/인", "전 기능 포함"),
            ("추가 스토리지", "5,000원/100GB", "4,000원/100GB", "선택사항"),
            ("프리미엄 지원", "3,000원/인", "2,500원/인", "선택사항"),
        ],
        "implementation_cost_text": (
            "초기 도입 비용은 다음과 같습니다:\n"
            "  - 셋업 및 환경 구성: 500만 원\n"
            "  - 데이터 마이그레이션: 300만 원\n"
            "  - 관리자/사용자 교육: 200만 원\n"
            "  - 도입 비용 합계: 1,000만 원"
        ),
        "total_cost_text": (
            "320명 기준 연간 라이선스 비용:\n"
            "  12,000원 x 320명 x 12개월 = 46,080,000원\n\n"
            "초기 도입 비용: 10,000,000원\n\n"
            "1년 차 총 비용: 약 5,608만 원\n"
            "(IT 예산 2억 원 대비 약 28%)"
        ),
        "timeline_text": "표준 도입 일정은 약 8주(2개월)입니다.",
        "timeline_data": [
            ("1단계", "요구사항 분석 및 설계", "1주", "킥오프 미팅 포함"),
            ("2단계", "환경 구성 및 설정", "1주", "서버 구축, 보안 설정"),
            ("3단계", "데이터 마이그레이션", "2주", "기존 데이터 이관"),
            ("4단계", "파일럿 운영 (1개 부서)", "2주", "IT팀 우선 적용"),
            ("5단계", "전사 배포 및 교육", "1주", "전 부서 순차 배포"),
            ("6단계", "안정화 및 인수인계", "1주", "최종 점검"),
        ],
        "support_text": "워크플로우 프로는 24시간 365일 기술 지원을 제공합니다.",
        "support_details": [
            "24/7 전화 기술 지원",
            "전담 CS 매니저 배정 (1명)",
            "분기별 사용 현황 리포트 제공",
            "월 1회 정기 기술 미팅",
            "온라인 헬프센터 및 FAQ",
            "긴급 장애 시 2시간 내 초기 대응",
        ],
        "reference_text": "워크플로우 프로를 활용 중인 주요 고객사입니다.",
        "reference_data": [
            ("한국전자", "제조", "500명", "협업 시간 32% 단축"),
            ("파인금융", "금융", "300명", "문서 공유 효율 45% 개선"),
            ("메디케어플러스", "의료", "250명", "회의 시간 28% 감소"),
            ("스마트로지스", "물류", "400명", "프로젝트 지연률 40% 감소"),
        ],
        "contact_person": "김영진 팀장",
        "contact_email": "sales@workflowlab.co.kr",
        "contact_phone": "02-1234-5678",
    }

    # ── 벤더B: 팀콜라보 ──
    vendor_b = {
        "filename": "벤더B_팀콜라보_제안서.pdf",
        "company_name": "팀콜라보 주식회사",
        "product_name": "팀콜라보",
        "color_primary": (102, 51, 153),
        "color_accent": (153, 102, 204),
        "company_intro": (
            "팀콜라보 주식회사는 2020년 설립된 스타트업으로, '팀 단위 협업의 혁신'을 "
            "비전으로 빠르게 성장하고 있습니다. 직원 80명 규모이지만 국내 600개 이상의 "
            "고객사를 확보하며 높은 고객 만족도를 유지하고 있습니다."
        ),
        "company_highlights": [
            "설립: 2020년 (6년 차)",
            "직원 수: 80명 (R&D 인력 45명)",
            "고객사: 국내 600개사",
            "주요 인증: ISO 27001 준비 중",
            "누적 투자 유치: 120억 원 (Series B)",
        ],
        "solution_overview": (
            "팀콜라보는 팀 중심의 협업을 위해 설계된 차세대 협업 플랫폼입니다. "
            "메시징, 파일 공유, 화상회의, 할일 관리, 위키 기능을 팀 단위로 묶어 제공하며, "
            "빠른 온보딩과 직관적인 사용성이 강점입니다.\n\n"
            "귀사의 직원 320명, 5개 부서 환경에 맞춘 팀 기반 구성을 제안드립니다."
        ),
        "features": [
            ("메시징", "팀 채널, DM, 스레드 기반의 소통 기능을 제공합니다. "
             "실시간 번역(15개 언어), 메시지 예약 발송 기능이 특징입니다."),
            ("파일 공유", "팀당 50GB의 클라우드 스토리지를 제공합니다. "
             "드래그 앤 드롭 업로드, 파일 미리보기, 간편 공유 링크를 지원합니다."),
            ("화상회의", "최대 30인 동시 참여 가능한 화상회의를 제공합니다. "
             "화면 공유, 가상 배경 기능을 지원합니다. (녹화 기능은 2026년 하반기 추가 예정)"),
            ("할일 관리", "개인 및 팀 할일 관리, 우선순위 설정, 마감일 알림을 지원합니다. "
             "칸반 보드 형태로 작업 현황을 시각화할 수 있습니다."),
            ("위키", "팀별 지식 베이스를 구축할 수 있는 위키 기능을 제공합니다. "
             "마크다운 에디터, 버전 관리, 검색 기능을 지원합니다."),
            ("모바일", "반응형 웹으로 모바일 접속을 지원합니다. "
             "전용 앱은 2026년 3분기 출시 예정입니다."),
            ("보안", "SSO 연동, 기본 감사 로그, TLS 1.3 암호화를 지원합니다. "
             "ISO 27001 인증은 2026년 내 취득 예정입니다."),
            ("외부 서비스 연동", "Gmail, Slack 연동을 기본 지원하며, "
             "Open API를 제공하여 커스텀 연동이 가능합니다."),
        ],
        "pricing_text": "팀콜라보는 팀 단위 과금 체계로 비용을 최적화할 수 있습니다.",
        "pricing_table_header": [
            ("항목", 45), ("요금", 40), ("단위", 35), ("비고", 70),
        ],
        "pricing_table_data": [
            ("기본 팀 라이선스", "120,000원", "10인 팀/월", "최소 5팀"),
            ("추가 스토리지", "30,000원", "50GB/팀/월", "선택사항"),
            ("화상회의 확장", "50,000원", "100인/월", "기본 30인 초과 시"),
        ],
        "implementation_cost_text": (
            "초기 도입 비용은 다음과 같습니다:\n"
            "  - 셋업 및 환경 구성: 무료 (셀프 서비스)\n"
            "  - 데이터 마이그레이션: 200만 원\n"
            "  - 교육: 무료 (온라인 교육 동영상 제공)\n"
            "  - 도입 비용 합계: 200만 원"
        ),
        "total_cost_text": (
            "320명 기준 연간 라이선스 비용 (32팀 구성):\n"
            "  120,000원 x 32팀 x 12개월 = 46,080,000원\n\n"
            "초기 도입 비용: 2,000,000원\n\n"
            "1년 차 총 비용: 약 4,808만 원\n"
            "(IT 예산 2억 원 대비 약 24%)"
        ),
        "timeline_text": "팀콜라보는 빠른 도입이 강점입니다. 표준 도입 일정은 약 4주입니다.",
        "timeline_data": [
            ("1단계", "요구사항 확인", "3일", "온라인 미팅"),
            ("2단계", "환경 구성", "2일", "클라우드 자동 프로비저닝"),
            ("3단계", "데이터 마이그레이션", "1주", "자동 마이그레이션 도구"),
            ("4단계", "파일럿 (1개 팀)", "1주", "피드백 수집"),
            ("5단계", "전사 배포", "1주", "순차 배포"),
            ("6단계", "안정화", "3일", "모니터링"),
        ],
        "support_text": "팀콜라보는 빠르고 친절한 고객 지원을 제공합니다.",
        "support_details": [
            "평일 9:00~18:00 이메일/채팅 지원",
            "평균 응답 시간: 2시간 이내",
            "온라인 헬프센터 및 동영상 가이드",
            "월 1회 웨비나 (신기능 소개, Q&A)",
            "커뮤니티 포럼 운영",
            "긴급 장애 시 4시간 내 대응 (프리미엄 플랜)",
        ],
        "reference_text": "팀콜라보를 활용 중인 주요 고객사입니다.",
        "reference_data": [
            ("디자인팩토리", "디자인", "150명", "프로젝트 소통 효율 50% 개선"),
            ("에듀테크코리아", "교육", "200명", "원격 협업 만족도 92%"),
            ("그린에너지", "에너지", "100명", "도입 2주 만에 전사 적용"),
            ("코드브릿지", "IT", "80명", "기존 대비 비용 40% 절감"),
        ],
        "contact_person": "박서연 매니저",
        "contact_email": "biz@teamcollabo.kr",
        "contact_phone": "02-9876-5432",
    }

    # ── 벤더C: 스마트워크 ──
    vendor_c = {
        "filename": "벤더C_스마트워크_제안서.pdf",
        "company_name": "스마트워크 주식회사",
        "product_name": "스마트워크",
        "color_primary": (0, 51, 102),
        "color_accent": (0, 102, 204),
        "company_intro": (
            "스마트워크 주식회사는 2015년 설립된 글로벌 협업 솔루션 기업입니다. "
            "직원 350명 규모로 국내 2,000개, 해외 500개 이상의 고객사를 보유하고 있으며, "
            "엔터프라이즈급 보안과 AI 기반 생산성 도구를 결합한 차세대 협업 플랫폼을 제공합니다."
        ),
        "company_highlights": [
            "설립: 2015년 (11년 차)",
            "직원 수: 350명 (R&D 인력 150명, AI팀 30명)",
            "고객사: 국내 2,000개 + 해외 500개 (15개국)",
            "주요 인증: ISO 27001, SOC 2 Type II, ISMS-P, CSA STAR",
            "연간 매출: 약 580억 원 (2025년 기준)",
        ],
        "solution_overview": (
            "스마트워크는 메시징, 파일 공유, 화상회의, 프로젝트 관리, 대시보드, "
            "AI 어시스턴트를 통합한 올인원 협업 플랫폼입니다. 기능별 모듈 과금 체계로 "
            "필요한 기능만 선택하여 비용을 최적화할 수 있습니다.\n\n"
            "귀사의 직원 320명, 5개 부서 환경에 최적화된 엔터프라이즈 구성과 "
            "AI 기반 생산성 향상 방안을 제안드립니다."
        ),
        "features": [
            ("메시징 및 커뮤니케이션", "1:1/그룹/채널 메시징, 스레드, 실시간 번역(30개 언어), "
             "메시지 스케줄링, AI 요약, 읽음 확인, 메시지 리마인더를 지원합니다."),
            ("파일 공유 및 문서 관리", "사용자당 200GB 스토리지, 실시간 공동 편집, "
             "파일 버전 관리(최대 100개 버전), DLP(데이터 유출 방지), "
             "AI 기반 문서 자동 분류/태깅을 지원합니다."),
            ("화상회의", "최대 100인 동시 참여, HD 화질, 화면 공유, 녹화, "
             "실시간 자막(한/영/일/중), AI 회의록 자동 생성, "
             "배경 흐림/가상 배경, 소회의실 기능을 제공합니다."),
            ("프로젝트 관리", "간트 차트, 칸반, 타임라인, 리스트 뷰 등 다양한 뷰를 지원합니다. "
             "작업 의존성 관리, 리소스 할당, 자동 진척률 계산, "
             "포트폴리오 관리, AI 기반 일정 예측 기능을 제공합니다."),
            ("대시보드 및 분석", "팀별/부서별/전사 협업 현황 대시보드를 제공합니다. "
             "사용 패턴 분석, 생산성 인사이트, 커스텀 리포트 생성이 가능합니다."),
            ("AI 어시스턴트", "업무 자동화, 스마트 일정 관리, 문서 요약, "
             "미팅 어시스턴트, 개인화된 업무 추천 기능을 제공합니다."),
            ("모바일 및 데스크톱", "iOS, Android, iPad 전용 앱과 Windows, macOS 데스크톱 앱을 제공합니다. "
             "오프라인 모드를 지원하여 네트워크 없이도 기본 기능을 이용할 수 있습니다."),
            ("보안 및 컴플라이언스", "SSO(SAML 2.0, OAuth 2.0, OpenID Connect), "
             "상세 감사 로그, AES-256 암호화, ISO 27001 + SOC 2 Type II 인증, "
             "DLP, IP 접근 제어, 디바이스 관리(MDM 연동)를 지원합니다."),
            ("외부 서비스 연동", "Outlook, Google Workspace, SAP, Oracle ERP, Salesforce, "
             "카카오워크, Jira, Confluence, Slack 등 50개 이상 서비스와 연동됩니다. "
             "Webhook, REST API, GraphQL API를 통한 커스텀 연동을 지원합니다."),
        ],
        "pricing_text": "스마트워크는 기능별 모듈 과금 체계로 필요한 기능만 선택 가능합니다.",
        "pricing_table_header": [
            ("모듈", 45), ("월 요금(인당)", 40), ("포함 기능", 105),
        ],
        "pricing_table_data": [
            ("기본 패키지", "5,000원", "메시징, 파일공유(200GB), 모바일앱"),
            ("화상회의", "3,000원", "100인 회의, 녹화, AI 자막"),
            ("프로젝트 관리", "4,000원", "간트/칸반, AI 일정 예측"),
            ("보안 패키지", "2,000원", "DLP, IP 제어, 고급 감사 로그"),
            ("AI 어시스턴트", "3,000원", "AI 요약, 자동화, 추천 (선택)"),
            ("전체 패키지", "14,000원", "위 전 모듈 포함 (AI 제외: 17,000원)"),
        ],
        "implementation_cost_text": (
            "초기 도입 비용은 다음과 같습니다:\n"
            "  - 셋업 및 환경 구성: 800만 원\n"
            "  - 데이터 마이그레이션: 500만 원\n"
            "  - 관리자/사용자 교육: 300만 원 (오프라인 3회 + 온라인)\n"
            "  - 도입 컨설팅: 400만 원 (업무 프로세스 분석, 최적 구성 설계)\n"
            "  - 도입 비용 합계: 2,000만 원"
        ),
        "total_cost_text": (
            "320명 기준 연간 라이선스 비용 (전체 패키지):\n"
            "  14,000원 x 320명 x 12개월 = 53,760,000원\n\n"
            "초기 도입 비용: 20,000,000원\n\n"
            "1년 차 총 비용: 약 7,376만 원\n"
            "(IT 예산 2억 원 대비 약 37%)\n\n"
            "※ AI 어시스턴트 포함 시: 14,000원 → 17,000원\n"
            "  17,000원 x 320명 x 12개월 = 65,280,000원\n"
            "  1년 차 총 비용(AI 포함): 약 8,528만 원"
        ),
        "timeline_text": "스마트워크 엔터프라이즈 도입 표준 일정은 약 12주(3개월)입니다.",
        "timeline_data": [
            ("1단계", "업무 프로세스 분석/컨설팅", "2주", "현행 분석, As-Is/To-Be"),
            ("2단계", "설계 및 환경 구성", "2주", "아키텍처, 보안 설정"),
            ("3단계", "데이터 마이그레이션", "2주", "검증 포함"),
            ("4단계", "파일럿 (2개 부서)", "2주", "IT팀 + 경영기획팀"),
            ("5단계", "전사 배포 및 교육", "2주", "순차 배포, 오프라인 교육"),
            ("6단계", "안정화 및 최적화", "2주", "성과 분석, 튜닝"),
        ],
        "support_text": "스마트워크는 엔터프라이즈 고객을 위한 프리미엄 지원 체계를 운영합니다.",
        "support_details": [
            "24/7 전화 및 채팅 기술 지원",
            "전담 CS 매니저 및 기술 어카운트 매니저(TAM) 배정",
            "분기별 비즈니스 리뷰 (사용 현황, ROI 분석, 개선 제안)",
            "월 1회 기술 미팅 및 신기능 교육",
            "긴급 장애 시 1시간 내 초기 대응",
            "연 2회 무상 커스터마이징 지원",
            "전용 지원 포털 및 지식 베이스",
        ],
        "reference_text": "스마트워크를 활용 중인 국내외 주요 고객사입니다.",
        "reference_data": [
            ("삼진전자", "제조", "3,000명", "협업 생산성 42% 향상"),
            ("한국금융지주", "금융", "1,500명", "보안 인시던트 65% 감소"),
            ("글로벌쉽핑", "물류", "800명", "글로벌 협업 효율 38% 개선"),
            ("메디라이프", "의료", "500명", "문서 관리 시간 55% 단축"),
            ("테크밸리(싱가포르)", "IT", "200명", "해외 도입 성공 사례"),
        ],
        "contact_person": "이준호 상무",
        "contact_email": "enterprise@smartwork.co.kr",
        "contact_phone": "02-5555-1234",
    }

    create_vendor_proposal(vendor_a)
    create_vendor_proposal(vendor_b)
    create_vendor_proposal(vendor_c)


# ═══════════════════════════════════════════════════════════════
# 5. AI튜터_도입_기획서_초안.pdf
# ═══════════════════════════════════════════════════════════════
def create_ai_tutor_draft():
    pdf = KoreanPDF()

    # ── 표지 ──
    pdf.add_page()
    pdf.ln(40)
    pdf.set_font("malgun", "B", 22)
    pdf.set_text_color(50, 50, 50)
    pdf.cell(0, 12, "사내 AI 업무 도우미 도입 기획서", align="C", new_x="LMARGIN", new_y="NEXT")
    pdf.ln(5)
    pdf.set_font("malgun", "", 16)
    pdf.set_text_color(180, 0, 0)
    pdf.cell(0, 10, "(초안)", align="C", new_x="LMARGIN", new_y="NEXT")

    pdf.ln(30)
    pdf.set_font("malgun", "", 12)
    pdf.set_text_color(80, 80, 80)
    pdf.cell(0, 8, "작성: 디지털혁신팀", align="C", new_x="LMARGIN", new_y="NEXT")
    pdf.cell(0, 8, "2026년 4월", align="C", new_x="LMARGIN", new_y="NEXT")

    pdf.ln(30)
    pdf.set_draw_color(200, 200, 200)
    pdf.rect(40, pdf.get_y(), 130, 30)
    pdf.set_y(pdf.get_y() + 5)
    pdf.set_font("malgun", "", 10)
    pdf.set_text_color(150, 150, 150)
    pdf.cell(0, 8, "본 문서는 초안이며, 검토 및 보완이 필요합니다.", align="C", new_x="LMARGIN", new_y="NEXT")
    pdf.cell(0, 8, "구체적인 수치와 근거는 추가 조사 후 보완 예정", align="C", new_x="LMARGIN", new_y="NEXT")

    # ── 1. 배경 및 목적 ──
    pdf.add_page()
    pdf.set_font("malgun", "B", 16)
    pdf.set_text_color(50, 50, 50)
    pdf.cell(0, 12, "1. 배경 및 목적", new_x="LMARGIN", new_y="NEXT")
    pdf.set_draw_color(150, 150, 150)
    pdf.line(10, pdf.get_y(), 200, pdf.get_y())
    pdf.ln(8)

    pdf.set_font("malgun", "", 11)
    pdf.set_text_color(0, 0, 0)
    pdf.multi_cell(0, 7,
        "최근 생성형 AI 기술이 빠르게 발전하고 있습니다. 많은 기업들이 AI를 업무에 "
        "도입하고 있으며, 우리 회사도 이에 뒤처지지 않기 위해 AI 업무 도우미를 도입할 "
        "필요가 있습니다.\n\n"
        "직원들의 반복적인 업무 시간을 줄이고, 생산성을 높이는 것이 주요 목적입니다."
    )

    # ── 2. 현황 분석 ──
    pdf.ln(10)
    pdf.set_font("malgun", "B", 16)
    pdf.set_text_color(50, 50, 50)
    pdf.cell(0, 12, "2. 현황 분석", new_x="LMARGIN", new_y="NEXT")
    pdf.set_draw_color(150, 150, 150)
    pdf.line(10, pdf.get_y(), 200, pdf.get_y())
    pdf.ln(8)

    pdf.set_font("malgun", "", 11)
    pdf.set_text_color(0, 0, 0)
    pdf.multi_cell(0, 7,
        "현재 직원들은 문서 작성, 이메일 응대, 데이터 정리 등에 하루 평균 많은 시간을 "
        "쓰고 있습니다. 특히 보고서 작성이나 회의록 정리 같은 업무는 시간이 오래 걸립니다.\n\n"
        "경쟁사들도 AI 도구를 도입하고 있는 것으로 파악됩니다."
    )

    # ── 3. 추진 방안 ──
    pdf.ln(10)
    pdf.set_font("malgun", "B", 16)
    pdf.set_text_color(50, 50, 50)
    pdf.cell(0, 12, "3. 추진 방안", new_x="LMARGIN", new_y="NEXT")
    pdf.set_draw_color(150, 150, 150)
    pdf.line(10, pdf.get_y(), 200, pdf.get_y())
    pdf.ln(8)

    pdf.set_font("malgun", "", 11)
    pdf.set_text_color(0, 0, 0)
    pdf.multi_cell(0, 7,
        "AI 업무 도우미를 도입합니다. 구체적으로는 생성형 AI 서비스를 사내에 도입하여 "
        "직원들이 활용할 수 있도록 합니다.\n\n"
        "  - 1단계: 파일럿 운영 (일부 부서)\n"
        "  - 2단계: 전사 확대\n"
        "  - 3단계: 고도화"
    )

    # ── 4. 기대 효과 ──
    pdf.ln(10)
    pdf.set_font("malgun", "B", 16)
    pdf.set_text_color(50, 50, 50)
    pdf.cell(0, 12, "4. 기대 효과", new_x="LMARGIN", new_y="NEXT")
    pdf.set_draw_color(150, 150, 150)
    pdf.line(10, pdf.get_y(), 200, pdf.get_y())
    pdf.ln(8)

    pdf.set_font("malgun", "", 11)
    pdf.set_text_color(0, 0, 0)
    pdf.multi_cell(0, 7,
        "  - 업무 효율이 향상될 것으로 기대됩니다\n"
        "  - 직원 만족도가 올라갈 것입니다\n"
        "  - 비용 절감 효과가 있을 것입니다"
    )

    # ── 5. 일정 및 예산 ──
    pdf.ln(10)
    pdf.set_font("malgun", "B", 16)
    pdf.set_text_color(50, 50, 50)
    pdf.cell(0, 12, "5. 일정 및 예산", new_x="LMARGIN", new_y="NEXT")
    pdf.set_draw_color(150, 150, 150)
    pdf.line(10, pdf.get_y(), 200, pdf.get_y())
    pdf.ln(8)

    pdf.set_font("malgun", "", 11)
    pdf.set_text_color(0, 0, 0)
    pdf.multi_cell(0, 7,
        "  - 파일럿: 약 2개월\n"
        "  - 전사 확대: 약 3개월\n"
        "  - 예산: 추후 산정 예정"
    )

    pdf.ln(15)
    pdf.set_draw_color(200, 200, 200)
    pdf.line(10, pdf.get_y(), 200, pdf.get_y())
    pdf.ln(5)
    pdf.set_font("malgun", "", 10)
    pdf.set_text_color(150, 150, 150)
    pdf.multi_cell(0, 6,
        "※ 본 기획서는 초안이며, 구체적인 수치와 근거는 추가 조사 후 보완 예정입니다."
    )

    output_path = os.path.join(OUTPUT_DIR, "AI튜터_도입_기획서_초안.pdf")
    pdf.output(output_path)
    print(f"  [OK] {output_path}")


# ═══════════════════════════════════════════════════════════════
# 6. 클라우드서비스_이용계약서.pdf
# ═══════════════════════════════════════════════════════════════
def create_contract():
    pdf = KoreanPDF()
    pdf.set_auto_page_break(auto=True, margin=30)

    # ── 표지 ──
    pdf.add_page()
    pdf.ln(50)
    pdf.set_draw_color(0, 0, 0)
    pdf.set_line_width(0.8)
    pdf.rect(30, 60, 150, 150)
    pdf.rect(31, 61, 148, 148)

    pdf.set_y(80)
    pdf.set_font("malgun", "B", 26)
    pdf.set_text_color(0, 0, 0)
    pdf.cell(0, 15, "소프트웨어 라이선스", align="C", new_x="LMARGIN", new_y="NEXT")
    pdf.cell(0, 15, "이용 계약서", align="C", new_x="LMARGIN", new_y="NEXT")

    pdf.ln(15)
    pdf.set_line_width(0.3)
    pdf.line(60, pdf.get_y(), 150, pdf.get_y())

    pdf.ln(15)
    pdf.set_font("malgun", "", 13)
    pdf.cell(0, 10, '공급사: 글로벌테크 주식회사', align="C", new_x="LMARGIN", new_y="NEXT")
    pdf.cell(0, 10, '이용사: 스마트솔루션 주식회사', align="C", new_x="LMARGIN", new_y="NEXT")

    pdf.ln(10)
    pdf.set_font("malgun", "", 12)
    pdf.cell(0, 10, "2026년", align="C", new_x="LMARGIN", new_y="NEXT")

    # ── 계약서 본문 ──
    # 전문
    pdf.add_page()
    pdf.set_font("malgun", "B", 16)
    pdf.set_text_color(0, 0, 0)
    pdf.cell(0, 12, "소프트웨어 라이선스 이용 계약서", align="C", new_x="LMARGIN", new_y="NEXT")
    pdf.ln(5)
    pdf.set_draw_color(0, 0, 0)
    pdf.set_line_width(0.5)
    pdf.line(10, pdf.get_y(), 200, pdf.get_y())
    pdf.ln(8)

    pdf.set_font("malgun", "", 11)
    pdf.set_line_width(0.2)
    pdf.multi_cell(0, 8,
        '글로벌테크 주식회사 (이하 "공급사")와 스마트솔루션 주식회사 (이하 "이용사") 간에 '
        '다음과 같이 소프트웨어 라이선스 이용 계약을 체결한다.'
    )
    pdf.ln(6)

    # 계약 조항들
    articles = [
        ("제1조 (목적)", [
            '본 계약은 공급사가 개발한 "GlobalSuite Enterprise" 소프트웨어(이하 "소프트웨어")의 '
            '라이선스 이용에 관한 양 당사자의 권리와 의무를 정함을 목적으로 한다.',
        ]),
        ("제2조 (정의)", [
            '1. "소프트웨어"라 함은 GlobalSuite Enterprise 프로그램 및 관련 문서, 업데이트를 포함한다.',
            '2. "이용자"라 함은 이용사의 임직원으로서 소프트웨어를 사용할 권한을 부여받은 자를 말한다.',
            '3. "라이선스"라 함은 본 계약에 따라 이용사에게 부여되는 소프트웨어 사용 권한을 말한다.',
        ]),
        ("제3조 (라이선스 부여)", [
            '1. 공급사는 이용사에게 50인 기준 소프트웨어 이용 라이선스를 비독점적으로 부여한다.',
            '2. 라이선스는 이용사의 대한민국 내 사업장에서만 사용할 수 있다.',
            '3. 이용사는 공급사의 사전 서면 동의 없이 라이선스를 제3자에게 양도, 재판매, 대여할 수 없다.',
        ]),
        ("제4조 (계약 기간)", [
            '1. 본 계약의 유효기간은 계약 체결일로부터 3년간으로 한다.',
            '2. 계약 만료 90일 전까지 어느 일방이 서면으로 해지 통보하지 않는 한, 동일 조건으로 1년씩 자동 연장된다.',
            '3. 자동 연장 시 이용료는 소비자물가지수 변동률을 반영하여 최대 연 5%까지 인상될 수 있다.',
        ]),
        ("제5조 (이용료 및 결제)", [
            '1. 연간 라이선스 이용료는 금 일억이천만 원(\u20a9120,000,000)으로 한다.',
            '2. 이용료는 계약 체결 후 30일 이내에 전액 선납하며, 이후 매년 갱신일 30일 전까지 납부한다.',
            '3. 납부 기한을 초과할 경우, 미납 금액에 대해 연 15%의 지연 이자가 부과된다.',
            '4. 이용사의 이용자 수가 50인을 초과할 경우, 초과 이용자 1인당 월 5만 원의 추가 요금이 발생한다.',
        ]),
        ("제6조 (서비스 수준 보장, SLA)", [
            '1. 공급사는 소프트웨어의 월간 가용성(uptime)을 99.5% 이상으로 보장한다.',
            '2. 장애 발생 시 대응 시간: 긴급(4시간 이내), 일반(24시간 이내), 경미(72시간 이내)',
            '3. SLA 미달 시, 해당 월 이용료의 10%를 크레딧으로 보상한다.',
            '4. 단, 천재지변, 이용사의 귀책사유, 사전 공지된 정기 점검은 SLA 산정에서 제외한다.',
        ]),
        ("제7조 (데이터 보호 및 보안)", [
            '1. 공급사는 이용사의 데이터를 대한민국 내 데이터센터에서만 저장 및 처리한다.',
            '2. 공급사는 이용사의 데이터를 계약 목적 외에 사용하거나 제3자에게 제공하지 않는다.',
            '3. 개인정보 처리 관련 사항은 별도의 개인정보처리위탁계약에 따른다.',
            '4. 계약 종료 시, 공급사는 이용사의 요청에 따라 30일 이내에 모든 데이터를 반환하거나 파기한다.',
        ]),
        ("제8조 (지적재산권)", [
            '1. 소프트웨어에 대한 모든 지적재산권은 공급사에 귀속한다.',
            '2. 이용사가 소프트웨어를 이용하여 생성한 데이터 및 결과물의 소유권은 이용사에 귀속한다.',
            '3. 이용사는 소프트웨어를 역공학(reverse engineering), 디컴파일(decompile), '
            '디어셈블(disassemble)하는 행위를 할 수 없다.',
        ]),
        ("제9조 (기밀유지)", [
            '1. 양 당사자는 계약 이행 과정에서 취득한 상대방의 기밀정보를 계약 기간 및 '
            '계약 종료 후 3년간 비밀로 유지하여야 한다.',
            '2. 법원의 명령 또는 관련 법률에 의해 공개가 요구되는 경우는 예외로 한다.',
        ]),
        ("제10조 (보증 및 면책)", [
            '1. 공급사는 소프트웨어가 제품 설명서에 기재된 사양에 따라 작동함을 보증한다.',
            '2. 상기 보증은 제공되는 유일한 보증이며, 상품성, 특정 목적에의 적합성 등 '
            '묵시적 보증은 제외된다.',
            '3. 공급사의 총 손해배상 책임은 어떠한 경우에도 직전 12개월 간 이용사가 '
            '납부한 이용료 총액을 초과하지 않는다.',
            '4. 간접 손해, 결과적 손해, 일실 이익에 대해서는 어떠한 경우에도 책임을 지지 않는다.',
        ]),
        ("제11조 (계약 해지)", [
            '1. 어느 일방이 본 계약을 위반하고, 서면 통보 후 30일 이내에 시정하지 않을 경우, '
            '상대방은 계약을 해지할 수 있다.',
            '2. 이용사가 파산, 회생 절차를 신청하거나 지급 불능 상태에 빠진 경우, '
            '공급사는 즉시 계약을 해지할 수 있다.',
            '3. 이용사의 귀책사유로 계약이 해지되는 경우, 이미 납부한 이용료는 반환되지 않는다.',
            '4. 공급사의 귀책사유로 계약이 해지되는 경우, 잔여 기간에 대한 이용료를 일할 계산하여 반환한다.',
        ]),
        ("제12조 (불가항력)", [
            '천재지변, 전쟁, 테러, 정부 규제, 전염병 등 당사자의 합리적 통제 범위를 벗어나는 '
            '사유로 인해 계약상 의무를 이행할 수 없는 경우, 해당 기간 동안 의무 이행이 면제된다. '
            '단, 불가항력 사유가 90일을 초과하여 계속되는 경우, 어느 일방이든 계약을 해지할 수 있다.',
        ]),
        ("제13조 (분쟁 해결)", [
            '1. 본 계약에 관한 분쟁은 대한민국 법률에 따라 해석되고 규율된다.',
            '2. 분쟁 발생 시 양 당사자는 우선 성실히 협의하여 해결하기로 한다.',
            '3. 협의가 이루어지지 않을 경우, 서울중앙지방법원을 관할법원으로 한다.',
        ]),
        ("제14조 (일반 조항)", [
            '1. 본 계약은 양 당사자 간의 완전한 합의를 구성하며, 이전의 모든 구두 또는 '
            '서면 합의를 대체한다.',
            '2. 본 계약의 수정은 양 당사자의 권한 있는 대표가 서명한 서면에 의해서만 가능하다.',
            '3. 본 계약의 일부 조항이 무효로 판명되더라도 나머지 조항의 효력에는 영향을 미치지 않는다.',
        ]),
    ]

    for art_title, art_items in articles:
        # 조항 제목
        pdf.set_font("malgun", "B", 12)
        pdf.set_text_color(0, 0, 0)
        pdf.ln(4)
        pdf.cell(0, 10, art_title, new_x="LMARGIN", new_y="NEXT")
        pdf.ln(2)

        # 조항 내용
        pdf.set_font("malgun", "", 11)
        for item in art_items:
            pdf.multi_cell(0, 8, item)
            pdf.ln(1)

    # ── 서명란 ──
    pdf.ln(10)
    pdf.set_draw_color(0, 0, 0)
    pdf.set_line_width(0.3)
    pdf.line(10, pdf.get_y(), 200, pdf.get_y())
    pdf.ln(8)

    pdf.set_font("malgun", "", 12)
    pdf.cell(0, 10, "2026년      월      일", align="C", new_x="LMARGIN", new_y="NEXT")
    pdf.ln(15)

    # 공급사 서명란
    pdf.set_font("malgun", "B", 12)
    pdf.cell(95, 8, "공급사: 글로벌테크 주식회사")
    pdf.cell(95, 8, "이용사: 스마트솔루션 주식회사", new_x="LMARGIN", new_y="NEXT")
    pdf.ln(10)

    pdf.set_font("malgun", "", 11)
    pdf.cell(95, 8, "대표이사:  ___________________  (인)")
    pdf.cell(95, 8, "대표이사:  ___________________  (인)", new_x="LMARGIN", new_y="NEXT")
    pdf.ln(5)
    pdf.cell(95, 8, "주소: _________________________")
    pdf.cell(95, 8, "주소: _________________________", new_x="LMARGIN", new_y="NEXT")
    pdf.ln(3)
    pdf.cell(95, 8, "사업자번호: ____________________")
    pdf.cell(95, 8, "사업자번호: ____________________", new_x="LMARGIN", new_y="NEXT")

    output_path = os.path.join(OUTPUT_DIR, "클라우드서비스_이용계약서.pdf")
    pdf.output(output_path)
    print(f"  [OK] {output_path}")


# ═══════════════════════════════════════════════════════════════
# 메인 실행
# ═══════════════════════════════════════════════════════════════
if __name__ == "__main__":
    print("=" * 60)
    print("Chapter 5 실습용 PDF 생성 시작")
    print("=" * 60)
    print(f"출력 디렉토리: {OUTPUT_DIR}\n")

    print("[1/6] 경쟁사 분석 보고서...")
    create_competitor_report()

    print("[2/6] 벤더A 워크플로우프로 제안서...")
    print("[3/6] 벤더B 팀콜라보 제안서...")
    print("[4/6] 벤더C 스마트워크 제안서...")
    create_all_vendor_proposals()

    print("[5/6] AI튜터 도입 기획서 초안...")
    create_ai_tutor_draft()

    print("[6/6] 클라우드서비스 이용계약서...")
    create_contract()

    print("\n" + "=" * 60)
    print("모든 PDF 생성 완료!")
    print("=" * 60)

    # 파일 목록 및 크기 확인
    print(f"\n생성된 파일 목록:")
    for f in sorted(os.listdir(OUTPUT_DIR)):
        if f.endswith(".pdf"):
            fpath = os.path.join(OUTPUT_DIR, f)
            size = os.path.getsize(fpath)
            if size >= 1024 * 1024:
                size_str = f"{size / 1024 / 1024:.1f} MB"
            else:
                size_str = f"{size / 1024:.1f} KB"
            print(f"  {f:45s} {size_str:>10s}")
