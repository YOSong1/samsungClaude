# 실습용 샘플 파일 / Sample Files for Exercises

이 폴더에는 책의 실습에서 사용하는 샘플 파일이 포함되어 있습니다.
This folder contains sample files used in the book's exercises.

## 📁 폴더 구조 / Folder Structure

- `kr/` — 한국어판 샘플 파일
- `en/` — English edition sample files

## Chapter 5: 문서 업무 / Document Tasks

| 실습 | Exercise | 파일 (KR) | File (EN) |
|------|----------|-----------|-----------|
| 실습 1 (보고서 요약) | Ex 1 (Report Summary) | `kr/chapter5/경쟁사_분석_보고서_샘플.pdf` | `en/chapter5/competitor_analysis_report_sample.pdf` |
| 실습 2 (회의록 정리) | Ex 2 (Meeting Minutes) | `kr/chapter5/회의록_원본_샘플.txt` | `en/chapter5/meeting_transcript_sample.txt` |
| 실습 3 (벤더 비교) | Ex 3 (Vendor Comparison) | `kr/chapter5/벤더A_워크플로우프로_제안서.pdf` 외 2개 | `en/chapter5/vendor_A_workflow_pro_proposal.pdf` + 2 more |
| 실습 5 (기획서 검토) | Ex 5 (Proposal Review) | `kr/chapter5/AI튜터_도입_기획서_초안.pdf` | `en/chapter5/AI_tutor_proposal_draft.pdf` |
| 실습 8 (계약서 검토) | Ex 8 (Contract Review) | `kr/chapter5/클라우드서비스_이용계약서.pdf` | `en/chapter5/cloud_service_agreement.pdf` |
| 실습 9 (VOC 분석) | Ex 9 (VOC Analysis) | `kr/chapter5/고객문의_모음_샘플.txt` | `en/chapter5/customer_inquiries_sample.txt` |

## Chapter 6: 데이터 분석 / Data Analysis

| 실습 | Exercise | 파일 (KR) | File (EN) |
|------|----------|-----------|-----------|
| 실습 1-4, 8-9, 11 | Ex 1-4, 8-9, 11 | `kr/chapter6/2026년_주문데이터.xlsx` | `en/chapter6/2026_order_data.xlsx` |
| 실습 5-7, 12 | Ex 5-7, 12 | `kr/chapter6/고객데이터_정제전.xlsx` | `en/chapter6/customer_data_raw.xlsx` |
| 실습 10 | Ex 10 | `kr/chapter6/2026_부서별_비용집행.xlsx` | `en/chapter6/2026_dept_expenses.xlsx` |
| 패턴 2 | Pattern 2 | `kr/chapter6/3월_4월_매출비교.xlsx` | `en/chapter6/mar_apr_sales_comparison.xlsx` |

## Chapter 7: 정보 수집과 보고서 / Research & Reports

| 실습 | Exercise | 파일 (KR) | File (EN) |
|------|----------|-----------|-----------|
| 실습 5 (번역) | Ex 5 (Translation) | `kr/chapter7/영문_보고서_샘플.txt` | `en/chapter7/english_report_sample.txt` |
| 실습 7 (종합 보고서) | Ex 7 (Comprehensive Report) | `kr/chapter7/조사자료_모음_샘플.txt` | `en/chapter7/research_data_collection_sample.txt` |
