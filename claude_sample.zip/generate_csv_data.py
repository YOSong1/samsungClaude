import csv
import random
import os
from datetime import datetime, timedelta

random.seed(42)

SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))

# Korean names
SURNAMES = ['김', '이', '박', '최', '정', '한', '조', '윤', '임', '장', '오', '송', '강', '신', '허']
GIVEN_NAMES_M = ['민수', '준호', '우진', '서준', '건우', '현우', '지호', '시우', '도윤', '예준', '태현', '승민']
GIVEN_NAMES_F = ['서연', '하은', '지은', '소희', '다은', '수진', '채원', '지아', '예준', '소율', '민지', '유진']

PRODUCTS = ['A제품', 'B제품', 'C제품', 'D제품', 'E제품', 'F제품', 'G제품']
REGIONS = ['서울', '부산', '대구', '인천', '광주', '대전', '울산']
MANAGERS = ['김민수', '박준호', '최서영', '정우진', '한소희']
CUSTOMER_TYPES = ['신규', '기존', 'VIP']
DISCOUNTS = [0, 5, 10, 15, 20]

CATEGORIES_15 = ['스마트폰', '태블릿', '노트북', '데스크탑', '모니터', '키보드', '마우스',
                 '이어폰', '스피커', '충전기', '케이블', '파우치', '스탠드', '마우스패드', '웹캠']

DEPARTMENTS = ['영업팀', '마케팅팀', '개발팀', '인사팀', '재무팀', '고객지원팀', '기획팀']
EXPENSE_TYPES = ['출장비', '마케팅비', '운영비', '교육비', '인건비', '장비구매', '외주비']

def random_date(year, month_start=1, month_end=12):
    start = datetime(year, month_start, 1)
    if month_end == 12:
        end = datetime(year, 12, 31)
    else:
        end = datetime(year, month_end, 28)
    delta = (end - start).days
    return start + timedelta(days=random.randint(0, delta))

def random_korean_name():
    surname = random.choice(SURNAMES)
    given = random.choice(GIVEN_NAMES_M + GIVEN_NAMES_F)
    return surname + given

# ============================================================
# 1. 2026년_주문데이터.csv (1200 rows)
# ============================================================
print("Generating 2026년_주문데이터.csv...")
filepath = os.path.join(SCRIPT_DIR, '2026년_주문데이터.csv')
with open(filepath, 'w', newline='', encoding='utf-8-sig') as f:
    writer = csv.writer(f)
    writer.writerow(['주문일자', '주문번호', '제품명', '카테고리', '지역', '담당자', '고객유형', '수량', '매출금액', '할인율'])
    for i in range(1, 1201):
        date = random_date(2026)
        order_no = f'ORD-2026-{i:05d}'
        product = random.choice(PRODUCTS)
        category = '전자기기'
        region = random.choice(REGIONS)
        manager = random.choice(MANAGERS)
        cust_type = random.choices(CUSTOMER_TYPES, weights=[40, 40, 20])[0]
        qty = random.randint(1, 15)
        # Base price varies by product
        base_prices = {'A제품': 160000, 'B제품': 155000, 'C제품': 140000, 'D제품': 200000,
                       'E제품': 180000, 'F제품': 210000, 'G제품': 130000}
        base = base_prices[product]
        amount = int(base * qty * random.uniform(0.85, 1.15))
        discount = random.choice(DISCOUNTS)
        writer.writerow([date.strftime('%Y-%m-%d'), order_no, product, category, region,
                         manager, cust_type, qty, f'{amount:,}', discount])

# ============================================================
# 2. 고객데이터_정제전.csv (305 rows with messy data)
# ============================================================
print("Generating 고객데이터_정제전.csv...")
filepath = os.path.join(SCRIPT_DIR, '고객데이터_정제전.csv')

def random_phone():
    formats = [
        lambda: f'+82 10-{random.randint(1000,9999)}-{random.randint(1000,9999)}',
        lambda: f'010{random.randint(10000000,99999999)}',
        lambda: f'010 {random.randint(1000,9999)} {random.randint(1000,9999)}',
        lambda: f'010-{random.randint(1000,9999)}-{random.randint(1000,9999)}',
    ]
    return random.choice(formats)()

def random_email(name):
    domains = ['hanmail.net', 'naver.com', 'gmail.com', 'daum.net', 'kakao.com']
    num = random.randint(10, 99)
    email = f'{name}{num}@{random.choice(domains)}'
    case = random.choice(['lower', 'upper', 'mixed'])
    if case == 'upper':
        return email.upper()
    elif case == 'mixed':
        return email[0].upper() + email[1:]
    return email

with open(filepath, 'w', newline='', encoding='utf-8-sig') as f:
    writer = csv.writer(f)
    writer.writerow(['고객ID', '이름', '연락처', '이메일', '나이', '고객유형', '총구매횟수', '선호카테고리'])

    names_used = []
    for i in range(1, 306):
        cid = f'C{i:04d}'
        name = random_korean_name()
        names_used.append(name)
        phone = random_phone()
        email = random_email(name)

        # Normal age range with a few outliers
        if random.random() < 0.02:
            age = random.choice([5, 8, 150, 200, -3])  # outliers
        elif random.random() < 0.03:
            age = ''  # missing
        else:
            age = random.randint(18, 65)

        cust_type = random.choices(['VIP', '재구매', '신규', '일반'], weights=[15, 25, 30, 30])[0]

        if random.random() < 0.03:
            purchases = ''  # missing
        else:
            purchases = random.randint(1, 50)

        category = random.choice(CATEGORIES_15)

        writer.writerow([cid, name, phone, email, age, cust_type, purchases, category])

    # Add ~10 duplicate rows (same email, different name casing)
    for _ in range(10):
        idx = random.randint(0, 280)
        orig_name = names_used[idx]
        cid = f'C{305 + _ + 1:04d}'  # This will exceed 305 but that's OK for messiness
        writer.writerow([f'C{random.randint(1,305):04d}', orig_name, random_phone(),
                         random_email(orig_name), random.randint(18, 65),
                         random.choice(['VIP', '재구매', '신규', '일반']),
                         random.randint(1, 50), random.choice(CATEGORIES_15)])

# ============================================================
# 3. 2026_부서별_비용집행.csv (343 rows)
# ============================================================
print("Generating 2026_부서별_비용집행.csv...")
filepath = os.path.join(SCRIPT_DIR, '2026_부서별_비용집행.csv')
with open(filepath, 'w', newline='', encoding='utf-8-sig') as f:
    writer = csv.writer(f)
    writer.writerow(['집행일자', '부서', '비용항목', '금액', '분기', '비고'])

    quarter_months = {'Q1': (1, 3), 'Q2': (4, 6), 'Q3': (7, 9), 'Q4': (10, 12)}

    for i in range(343):
        dept = random.choice(DEPARTMENTS)
        expense = random.choice(EXPENSE_TYPES)
        quarter = random.choice(['Q1', 'Q2', 'Q3', 'Q4'])
        m_start, m_end = quarter_months[quarter]
        date = random_date(2026, m_start, m_end)

        # Amount varies by department and type
        base = random.randint(500000, 15000000)
        if dept == '영업팀' and expense == '마케팅비':
            base = int(base * 1.5)
        elif dept == '개발팀' and expense == '장비구매':
            base = int(base * 1.3)

        note = ''
        if random.random() < 0.08:
            note = '긴급'
        elif random.random() < 0.05:
            note = '승인대기'

        writer.writerow([date.strftime('%Y-%m-%d'), dept, expense, f'{base:,}', quarter, note])

# Budget baseline
filepath = os.path.join(SCRIPT_DIR, '2026_부서별_예산기준.csv')
with open(filepath, 'w', newline='', encoding='utf-8-sig') as f:
    writer = csv.writer(f)
    writer.writerow(['부서', '연간예산'])
    budgets = {
        '영업팀': 450000000, '마케팅팀': 380000000, '개발팀': 500000000,
        '인사팀': 150000000, '재무팀': 120000000, '고객지원팀': 200000000, '기획팀': 180000000
    }
    for dept, budget in budgets.items():
        writer.writerow([dept, f'{budget:,}'])

# ============================================================
# 4. 3월/4월 매출 비교 (180 + 163 rows)
# ============================================================
print("Generating 3월_4월_매출비교 files...")
REGIONS_6 = ['서울', '부산', '인천', '대구', '광주', '대전']

filepath_mar = os.path.join(SCRIPT_DIR, '3월_4월_매출비교_3월.csv')
with open(filepath_mar, 'w', newline='', encoding='utf-8-sig') as f:
    writer = csv.writer(f)
    writer.writerow(['날짜', '제품명', '지역', '수량', '매출금액'])
    for i in range(180):
        day = random.randint(1, 31)
        if day > 31:
            day = 31
        date = f'2026-03-{min(day, 31):02d}'
        product = random.choice(PRODUCTS)
        region = random.choice(REGIONS_6)
        qty = random.randint(1, 12)
        base_prices = {'A제품': 195000, 'B제품': 160000, 'C제품': 145000, 'D제품': 210000,
                       'E제품': 185000, 'F제품': 220000, 'G제품': 135000}
        amount = int(base_prices[product] * qty * random.uniform(0.9, 1.1))
        writer.writerow([date, product, region, qty, f'{amount:,}'])

filepath_apr = os.path.join(SCRIPT_DIR, '3월_4월_매출비교_4월.csv')
with open(filepath_apr, 'w', newline='', encoding='utf-8-sig') as f:
    writer = csv.writer(f)
    writer.writerow(['날짜', '제품명', '지역', '수량', '매출금액'])
    for i in range(163):
        day = random.randint(1, 30)
        date = f'2026-04-{min(day, 30):02d}'
        product = random.choice(PRODUCTS)
        region = random.choice(REGIONS_6)
        qty = random.randint(1, 12)
        base_prices = {'A제품': 210000, 'B제품': 155000, 'C제품': 150000, 'D제품': 195000,
                       'E제품': 190000, 'F제품': 230000, 'G제품': 125000}
        amount = int(base_prices[product] * qty * random.uniform(0.9, 1.1))
        writer.writerow([date, product, region, qty, f'{amount:,}'])

print("All CSV files generated successfully!")
print(f"Files saved in: {SCRIPT_DIR}")
