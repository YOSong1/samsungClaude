"""
Chapter 6 실습용 XLSX 파일 생성 스크립트
CSV 파일을 읽어 한국어/영어 XLSX 파일로 변환합니다.
"""

import csv
import os
from openpyxl import Workbook
from openpyxl.styles import Font
from openpyxl.utils import get_column_letter

# 기본 경로
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
KR_CH6 = os.path.join(BASE_DIR, "kr", "chapter6")
EN_CH6 = os.path.join(BASE_DIR, "en", "chapter6")

# 출력 디렉토리 생성
os.makedirs(KR_CH6, exist_ok=True)
os.makedirs(EN_CH6, exist_ok=True)


def read_csv(filename):
    """CSV 파일을 읽어 2D 리스트로 반환"""
    filepath = os.path.join(BASE_DIR, filename)
    rows = []
    with open(filepath, "r", encoding="utf-8") as f:
        reader = csv.reader(f)
        for row in reader:
            rows.append(row)
    return rows


def auto_adjust_column_width(ws):
    """열 너비를 내용에 맞게 자동 조정"""
    for col_idx, col_cells in enumerate(ws.columns, 1):
        max_length = 0
        for cell in col_cells:
            if cell.value is not None:
                # 한글은 약 2배 너비 차지
                val = str(cell.value)
                length = 0
                for ch in val:
                    if ord(ch) > 127:
                        length += 2
                    else:
                        length += 1
                max_length = max(max_length, length)
        adjusted_width = min(max_length + 2, 50)
        ws.column_dimensions[get_column_letter(col_idx)].width = adjusted_width


def bold_header(ws):
    """첫 번째 행(헤더)을 볼드 처리"""
    bold_font = Font(bold=True)
    for cell in ws[1]:
        cell.font = bold_font


def write_sheet(ws, rows):
    """시트에 데이터 행 쓰기"""
    for row in rows:
        ws.append(row)
    bold_header(ws)
    auto_adjust_column_width(ws)


def create_single_sheet_xlsx(csv_file, output_path, sheet_name="Sheet1"):
    """단일 시트 XLSX 생성"""
    rows = read_csv(csv_file)
    wb = Workbook()
    ws = wb.active
    ws.title = sheet_name
    write_sheet(ws, rows)
    wb.save(output_path)
    print(f"  Created: {output_path}")


def create_multi_sheet_xlsx(csv_sheets, output_path):
    """
    다중 시트 XLSX 생성
    csv_sheets: [(csv_file, sheet_name), ...]
    """
    wb = Workbook()
    # 기본 시트 제거
    wb.remove(wb.active)

    for csv_file, sheet_name in csv_sheets:
        rows = read_csv(csv_file)
        ws = wb.create_sheet(title=sheet_name)
        write_sheet(ws, rows)

    wb.save(output_path)
    print(f"  Created: {output_path}")


def main():
    print("=" * 60)
    print("Chapter 6 XLSX 파일 생성")
    print("=" * 60)

    # ── 한국어 XLSX ──
    print("\n[한국어 XLSX 생성]")

    # a) 2026년_주문데이터.xlsx
    create_single_sheet_xlsx(
        "2026년_주문데이터.csv",
        os.path.join(KR_CH6, "2026년_주문데이터.xlsx"),
        sheet_name="주문데이터",
    )

    # b) 고객데이터_정제전.xlsx
    create_single_sheet_xlsx(
        "고객데이터_정제전.csv",
        os.path.join(KR_CH6, "고객데이터_정제전.xlsx"),
        sheet_name="고객데이터",
    )

    # c) 2026_부서별_비용집행.xlsx (2시트)
    create_multi_sheet_xlsx(
        [
            ("2026_부서별_비용집행.csv", "비용집행"),
            ("2026_부서별_예산기준.csv", "예산기준"),
        ],
        os.path.join(KR_CH6, "2026_부서별_비용집행.xlsx"),
    )

    # d) 3월_4월_매출비교.xlsx (2시트)
    create_multi_sheet_xlsx(
        [
            ("3월_4월_매출비교_3월.csv", "3월"),
            ("3월_4월_매출비교_4월.csv", "4월"),
        ],
        os.path.join(KR_CH6, "3월_4월_매출비교.xlsx"),
    )

    # ── 영어 XLSX ──
    print("\n[영어 XLSX 생성]")

    # a) 2026_order_data.xlsx
    create_single_sheet_xlsx(
        "2026년_주문데이터.csv",
        os.path.join(EN_CH6, "2026_order_data.xlsx"),
        sheet_name="Order Data",
    )

    # b) customer_data_raw.xlsx
    create_single_sheet_xlsx(
        "고객데이터_정제전.csv",
        os.path.join(EN_CH6, "customer_data_raw.xlsx"),
        sheet_name="Customer Data",
    )

    # c) 2026_dept_expenses.xlsx (2시트)
    create_multi_sheet_xlsx(
        [
            ("2026_부서별_비용집행.csv", "Expenses"),
            ("2026_부서별_예산기준.csv", "Budget"),
        ],
        os.path.join(EN_CH6, "2026_dept_expenses.xlsx"),
    )

    # d) mar_apr_sales_comparison.xlsx (2시트)
    create_multi_sheet_xlsx(
        [
            ("3월_4월_매출비교_3월.csv", "March"),
            ("3월_4월_매출비교_4월.csv", "April"),
        ],
        os.path.join(EN_CH6, "mar_apr_sales_comparison.xlsx"),
    )

    print("\n완료! 총 8개 XLSX 파일 생성됨.")


if __name__ == "__main__":
    main()
